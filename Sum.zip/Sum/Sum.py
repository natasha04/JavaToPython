print(2+2)

# In Python, you can directly print the addition of two numbers inside the print statement.
# You can also assign the sum to another variable and print the sum.

sum = 3+4
print(sum)

# In Java, you would have to declare a variable with it's respective data type in order to initialize it.
# You will then be able to call it in the System.out.println statement in a function or main method.

# Remember to run the code in your respective IDEs so you can see the output.