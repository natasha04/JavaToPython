/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Natasha
 */
public class Sum {
    public static void main(String args[]){
        int sum = 3+4;
        System.out.println(2+2);
        System.out.println(sum);
    }
}

/* In Java, you can add two numbers inside the
System.out.println statement in order to give the output. 
Java understands the data type as integers. 
A variable sum with integer data type can also add two integers
and can be called in the System.out.println statement.
*/