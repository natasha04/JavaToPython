s = "Hi There!"
print(s)

# As you can see, it is fairly easy to declare a variable as any data type without using the keyword.
# In java, using the data type keyword is necessary in order for java to figure out what kind of data
# it is dealing with.

# Here, we have assigned a string to a variable s and printed it out without declaring that it is a string.
