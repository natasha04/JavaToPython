/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Natasha
 */
public class ExampleString {
    public static void main(String args[]){
        String str = "Hello";
        System.out.println(str);
        System.out.println("Hello World");
    }
}

/* In Java, you must always declare a string with it's data type as String before
it's use. Java can also directly print out strings enclosed in the double quotation 
marks. Another point to note is that in Java, using single quotation marks to declare 
a string is not correct. Single quotation marks are used for characters.
In Python however, the use of either single or double quotation marks is allowed for 
string declaration.
*/

