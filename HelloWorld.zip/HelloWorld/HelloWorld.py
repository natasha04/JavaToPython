print("Hello World")

# This is a basic Hello World program.
# We can use a simple print statement to print out Hello World.
# In Java, you use the System.out.println statement to print out something.

# Another point to note is that Java requires that we use ; and {} while writing code
# We use indentation in Python instead and it doesn't require ; at the end of statements

